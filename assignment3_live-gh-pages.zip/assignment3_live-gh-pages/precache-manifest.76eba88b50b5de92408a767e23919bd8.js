self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a34992b76711abfd61964e55ae66d357",
    "url": "/assignment3_live/index.html"
  },
  {
    "revision": "5a64b54c16d2412bb824",
    "url": "/assignment3_live/static/css/main.20c208fb.chunk.css"
  },
  {
    "revision": "77db57d878b43be16311",
    "url": "/assignment3_live/static/js/2.2855fd7a.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/assignment3_live/static/js/2.2855fd7a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5a64b54c16d2412bb824",
    "url": "/assignment3_live/static/js/main.2ce49d9a.chunk.js"
  },
  {
    "revision": "96a0bf2c4b074e77580a",
    "url": "/assignment3_live/static/js/runtime-main.305fbb55.js"
  }
]);